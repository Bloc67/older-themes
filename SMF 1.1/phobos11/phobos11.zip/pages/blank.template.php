<?php

function template_main()
{
	redirectexit();
} 
?>
