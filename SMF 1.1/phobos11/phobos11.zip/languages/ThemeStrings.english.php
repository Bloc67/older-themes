<?php
// Version: 1.1; ThemeStrings

$txt['phobos_sticky'] = 'Sticky topics';
$txt['phobos_normal'] = 'Normal topics';


?>